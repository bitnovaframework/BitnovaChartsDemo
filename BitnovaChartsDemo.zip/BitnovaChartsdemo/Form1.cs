﻿using Bitnova.UI.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static BitnovaChartsdemo.Form1;

namespace BitnovaChartsdemo
{
    public partial class Form1 : Form
    {
        private List<SalesData> salesData;
        private List<TemperatureData> tempData;
        private Timer updateTimer;
        private List<ExpenseData> expenseData;
        private List<PerformanceData> performanceData;
        private DataTable performanceTable;
        private Random rnd = new Random();
        private Random random = new Random();
        private DataTable salesTable;
        private Timer updateTimer1;
        private List<PerformanceLineData> performanceLineData;
        private List<BudgetData> budgetData;
        private DataTable bubbleData; 
        public Form1()
        {
            InitializeComponent();
            InitializeBarChart();
            InitializeAreaChart();
            InitializeDoughnutChart();
           InitializeRadarChart();
            InitializePolarChart();
          
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitializePieChart();
            InitializeLineChart();
            InitializeBubbleChart();
        }
        private void InitializeBarChart()
        {
            // Create sample data
            salesData = new List<SalesData>
            {
                new SalesData { Month = "Jan", Sales = 100, Region = "North" },
                new SalesData { Month = "Jan", Sales = 120, Region = "South" },
                new SalesData { Month = "Feb", Sales = 150, Region = "North" },
                new SalesData { Month = "Feb", Sales = 90,  Region = "South" },
                new SalesData { Month = "Mar", Sales = 200, Region = "North" },
                new SalesData { Month = "Mar", Sales = 110, Region = "South" }
            };

            // Configure existing BitnovaBarChart control
            bitnovaBarChart1.DataSource = salesData;
            bitnovaBarChart1.ValueMember = "Sales";
            bitnovaBarChart1.LabelMember = "Month";
            bitnovaBarChart1.SeriesMember = "Region";
            bitnovaBarChart1.YAxisLabel = "Sales ($)";
            bitnovaBarChart1.RealTime = false; // Change to true for live updates
            bitnovaBarChart1.ChartBackColor = Color.FromArgb(40, 40, 40);
            bitnovaBarChart1.ShowLegend = true;

            // Optional: Handle chart's DataBound event
            bitnovaBarChart1.DataBound += (s, e) =>
            {
                Text = $"Chart Updated: {DateTime.Now.ToShortTimeString()}";
            };

            // Force refresh (if the control exposes a RefreshChart or Invalidate method)
            bitnovaBarChart1.Invalidate();
        }

        private void InitializeAreaChart()
        {
            // Create initial data
            tempData = new List<TemperatureData>
            {
                new TemperatureData { Hour = "08:00", Temperature = 18.5 },
                new TemperatureData { Hour = "09:00", Temperature = 19.0 },
                new TemperatureData { Hour = "10:00", Temperature = 20.5 },
                new TemperatureData { Hour = "11:00", Temperature = 22.0 },
                new TemperatureData { Hour = "12:00", Temperature = 23.5 },
                new TemperatureData { Hour = "13:00", Temperature = 24.0 },
                new TemperatureData { Hour = "14:00", Temperature = 23.0 }
            };

            // Configure existing BitnovaAreaChart control
            bitnovaAreaChart1.DataSource = tempData;
            bitnovaAreaChart1.ValueMember = "Temperature";
            bitnovaAreaChart1.LabelMember = "Hour";
            bitnovaAreaChart1.LineColor = Color.SteelBlue;
            bitnovaAreaChart1.FillColor = Color.FromArgb(100, Color.SteelBlue);
            bitnovaAreaChart1.ChartBackColor = Color.FromArgb(30, 30, 30);
            bitnovaAreaChart1.EnableAnimation = true;
            bitnovaAreaChart1.EnableHover = true;
            bitnovaAreaChart1.AnimationSpeed = 30;

            // Handle DataRefreshed event
            bitnovaAreaChart1.DataRefreshed += (s, e) =>
            {
                Text = $"Chart Updated: {DateTime.Now:HH:mm:ss}";
            };

            // Start a timer for simulating live data updates
            updateTimer = new Timer { Interval = 5000 };
            updateTimer.Tick += (s, e) =>
            {
                var newReading = new TemperatureData
                {
                    Hour = DateTime.Now.ToString("HH:mm"),
                    Temperature = 18 + new Random().NextDouble() * 6
                };

                tempData.Add(newReading);

                // Keep only the last 10 readings for a clean view (optional)
                if (tempData.Count > 10)
                    tempData.RemoveAt(0);

                // Refresh chart with updated data
                bitnovaAreaChart1.DataSource = null;
                bitnovaAreaChart1.DataSource = tempData;
            };

            updateTimer.Start();
        }
        public class TemperatureData
        {
            public string Hour { get; set; }
            public double Temperature { get; set; }
        }
        public class SalesData
        {
            public string Month { get; set; }
            public double Sales { get; set; }
            public string Region { get; set; }
        }
        private void InitializeDoughnutChart()
        {
            // Create initial data
            expenseData = new List<ExpenseData>
            {
                new ExpenseData { Category = "Food", Amount = 300 },
                new ExpenseData { Category = "Travel", Amount = 500 },
                new ExpenseData { Category = "Supplies", Amount = 150 },
                new ExpenseData { Category = "Rent", Amount = 800 },
                new ExpenseData { Category = "Utilities", Amount = 200 }
            };

            // Configure existing BitnovaDoughnutChart control
            bitnovaDoughnutChart1.DataSource = expenseData;
            bitnovaDoughnutChart1.ValueMember = "Amount";
            bitnovaDoughnutChart1.LabelMember = "Category";
            bitnovaDoughnutChart1.ChartBackColor = Color.FromArgb(30, 30, 30);
            bitnovaDoughnutChart1.ShowLegend = true;
            bitnovaDoughnutChart1.InnerRadiusPadding = 10;
            bitnovaDoughnutChart1.EnableAnimations = true;
            bitnovaDoughnutChart1.EnableHover = true;
            bitnovaDoughnutChart1.RefreshInterval = 5000;

            bitnovaDoughnutChart1.BackgroundColors = new List<Color>
            {
                Color.FromArgb(255, 100, 100),
                Color.FromArgb(100, 255, 100),
                Color.FromArgb(100, 100, 255),
                Color.FromArgb(255, 255, 100),
                Color.FromArgb(255, 100, 255)
            };

            // Handle DataRefreshed event
            bitnovaDoughnutChart1.DataRefreshed += (s, e) =>
            {
                Text = $"Chart Updated: {DateTime.Now:HH:mm:ss}";
            };

            // Start timer to simulate data updates
            updateTimer = new Timer { Interval = 5000 };
            updateTimer.Tick += (s, e) =>
            {
                var rnd = new Random();

                expenseData.Add(new ExpenseData
                {
                    Category = new[] { "Food", "Travel", "Supplies", "Rent", "Utilities" }[rnd.Next(0, 5)],
                    Amount = 100 + rnd.NextDouble() * 700
                });

                // Keep chart from overloading with too many slices
                if (expenseData.Count > 15)
                    expenseData.RemoveAt(0);

                // Refresh the chart
                bitnovaDoughnutChart1.DataSource = null;
                bitnovaDoughnutChart1.DataSource = expenseData;
            };

            updateTimer.Start();
        }
        public class ExpenseData
        {
            public string Category { get; set; }
            public double Amount { get; set; }
            public string Department { get; set; }
        }


        private void InitializeRadarChart()
        {
            // Create a DataTable (this avoids the delegate creation path in BindData)
            performanceTable = new DataTable();
            performanceTable.Columns.Add("Metric", typeof(string));
            performanceTable.Columns.Add("Value", typeof(double));
            performanceTable.Columns.Add("Team", typeof(string));

            // Add initial rows
            performanceTable.Rows.Add("Speed", 80d, "Team A");
            performanceTable.Rows.Add("Speed", 70d, "Team B");
            performanceTable.Rows.Add("Accuracy", 90d, "Team A");
            performanceTable.Rows.Add("Accuracy", 60d, "Team B");
            performanceTable.Rows.Add("Efficiency", 75d, "Team A");
            performanceTable.Rows.Add("Efficiency", 85d, "Team B");
            performanceTable.Rows.Add("Reliability", 85d, "Team A");
            performanceTable.Rows.Add("Reliability", 80d, "Team B");

            // Configure the existing designer-placed control (bitnovaRadarChart1)
            bitnovaRadarChart1.DataSource = performanceTable;
            bitnovaRadarChart1.LabelMember = "Metric";
            bitnovaRadarChart1.ValueMember = "Value";
            bitnovaRadarChart1.SeriesMember = "Team";
            bitnovaRadarChart1.Title = "Team Performance Metrics";
            bitnovaRadarChart1.ScaleMax = 100;
            bitnovaRadarChart1.GridLineCount = 5;
            bitnovaRadarChart1.ShowLegend = true;
            bitnovaRadarChart1.Fill = true;
            bitnovaRadarChart1.BorderColor = Color.SteelBlue;
            bitnovaRadarChart1.PointColor = Color.White;
            bitnovaRadarChart1.PointHoverColor = Color.Yellow;
            bitnovaRadarChart1.PointRadius = 6;
            bitnovaRadarChart1.PointHoverRadius = 8;
            bitnovaRadarChart1.RefreshInterval = 5000;

            // Subscribe to DataBound (EventHandler) and BindingError (EventHandler<Exception>)
            bitnovaRadarChart1.DataBound += BitnovaRadarChart1_DataBound;
            bitnovaRadarChart1.BindingError += BitnovaRadarChart1_BindingError;

            // Start timer to simulate dynamic updates
            updateTimer = new Timer { Interval = 5000 };
            updateTimer.Tick += UpdateTimer_Tick;
            updateTimer.Start();
        }

        private void BitnovaRadarChart1_DataBound(object sender, EventArgs e)
        {
            // update form title on successful bind
            Text = $"Chart Updated: {DateTime.Now:HH:mm:ss}";
        }

        private void BitnovaRadarChart1_BindingError(object sender, Exception ex)
        {
            // BindingError is EventHandler<Exception> in your control
            MessageBox.Show($"Data binding error: {ex.Message}", "Binding Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void UpdateTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                // Add a new random row (rotate among metrics and teams)
                string[] metrics = { "Speed", "Accuracy", "Efficiency", "Reliability" };
                string[] teams = { "Team A", "Team B" };
                var metric = metrics[rnd.Next(metrics.Length)];
                var team = teams[rnd.Next(teams.Length)];
                var value = 50 + rnd.NextDouble() * 50;

                // Add row to DataTable
                performanceTable.Rows.Add(metric, value, team);

                // Optionally keep table size manageable (remove oldest rows)
                if (performanceTable.Rows.Count > 40)
                    performanceTable.Rows.RemoveAt(0);

                // Rebind the DataTable to trigger a refresh
                bitnovaRadarChart1.DataSource = null;
                bitnovaRadarChart1.DataSource = performanceTable;
            }
            catch (Exception ex)
            {
                // If anything unexpected happens, surface it
                MessageBox.Show($"Update error: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        public class PerformanceData
        {
            public string Metric { get; set; }
            public double Value { get; set; }
            public string Team { get; set; }
        }
        private void InitializePolarChart()
        {
            // Create DataTable (avoids CreateDelegate path in some controls)
            salesTable = new DataTable();
            salesTable.Columns.Add("Category", typeof(string));
            salesTable.Columns.Add("Revenue", typeof(double));

            // Add initial rows
            salesTable.Rows.Add("Electronics", 5000d);
            salesTable.Rows.Add("Clothing", 3000d);
            salesTable.Rows.Add("Books", 2000d);
            salesTable.Rows.Add("Home", 4000d);
            salesTable.Rows.Add("Toys", 2500d);

            // Configure existing designer-placed control: bitnovaPolarChart1
            bitnovaPolarChart1.DataSource = salesTable;
            bitnovaPolarChart1.LabelMember = "Category";
            bitnovaPolarChart1.ValueMember = "Revenue";
            bitnovaPolarChart1.BackColor = Color.FromArgb(35, 35, 35);
            bitnovaPolarChart1.ShowLegend = true;
            bitnovaPolarChart1.RefreshInterval = 5000;

            // Set custom colors if property exists
            bitnovaPolarChart1.SeriesColors = new System.Collections.Generic.List<Color>
            {
                Color.FromArgb(255, 100, 100),
                Color.FromArgb(100, 255, 100),
                Color.FromArgb(100, 100, 255),
                Color.FromArgb(255, 255, 100),
                Color.FromArgb(255, 100, 255)
            };

            // Subscribe to refresh event.
            // The demo you shared used "OnDataRefreshed". If your control exposes that event, this will work:
            bitnovaPolarChart1.OnDataRefreshed += (s, e) =>
            {
                Text = $"Chart Updated: {DateTime.Now:HH:mm:ss}";
            };

          

            // Start timer to simulate dynamic updates
            updateTimer1 = new Timer { Interval = 5000 };
            updateTimer1.Tick += UpdateTimer1_Tick;
            updateTimer1.Start();
        }

        private void UpdateTimer1_Tick(object sender, EventArgs e)
        {
            try
            {
                // random new sales row
                string[] categories = { "Electronics", "Clothing", "Books", "Home", "Toys" };
                var category = categories[rnd.Next(categories.Length)];
                var revenue = 1000 + rnd.NextDouble() * 4;

                salesTable.Rows.Add(category, revenue);

                // keep table manageable
                if (salesTable.Rows.Count > 40)
                    salesTable.Rows.RemoveAt(0);

                // Rebind to force refresh
                bitnovaPolarChart1.DataSource = null;
                bitnovaPolarChart1.DataSource = salesTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Update error: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void InitializePieChart()
        {
            // ✅ Create sample data
            budgetData = new List<BudgetData>
            {
                new BudgetData { Category = "Rent", Amount = 1200 },
                new BudgetData { Category = "Utilities", Amount = 300 },
                new BudgetData { Category = "Food", Amount = 500 },
                new BudgetData { Category = "Transport", Amount = 200 },
                new BudgetData { Category = "Entertainment", Amount = 150 }
            };

            // ✅ Assign data AFTER form has loaded
            bitnovaPieChart1.ValueMember = "Amount";
            bitnovaPieChart1.LabelMember = "Category";
            bitnovaPieChart1.DataSource = budgetData;

            // ✅ Optional appearance setup
            bitnovaPieChart1.BackgroundColors = new List<Color>
            {
                Color.FromArgb(255, 100, 100),
                Color.FromArgb(100, 255, 100),
                Color.FromArgb(100, 100, 255),
                Color.FromArgb(255, 255, 100),
                Color.FromArgb(255, 100, 255)
            };

            bitnovaPieChart1.ChartBackColor = Color.FromArgb(30, 30, 30);
            bitnovaPieChart1.BorderColor = Color.Gray;
            bitnovaPieChart1.BorderWidth = 1.5f;
            bitnovaPieChart1.EnableHover = true;
            bitnovaPieChart1.EnableAnimation = true;
        }
    

    public class BudgetData
    {
        public string Category { get; set; }
        public double Amount { get; set; }
    }
        private void InitializeLineChart()
        {
            var performanceData = new List<PerformanceLineData>
    {
        new PerformanceLineData { Month = "Jan", Metric = 100, Team = "Team A" },
        new PerformanceLineData { Month = "Jan", Metric = 120, Team = "Team B" },
        new PerformanceLineData { Month = "Feb", Metric = 150, Team = "Team A" },
        new PerformanceLineData { Month = "Feb", Metric = 90,  Team = "Team B" },
        new PerformanceLineData { Month = "Mar", Metric = 200, Team = "Team A" },
        new PerformanceLineData { Month = "Mar", Metric = 110, Team = "Team B" },
        new PerformanceLineData { Month = "Apr", Metric = 180, Team = "Team A" },
        new PerformanceLineData { Month = "Apr", Metric = 130, Team = "Team B" }
    };

            bitnovaLineChart1.DataSource = performanceData;
            bitnovaLineChart1.LabelMember = "Month";
            bitnovaLineChart1.ValueMember = "Metric";
            bitnovaLineChart1.SeriesMember = "Team";
        }

        public class PerformanceLineData
        {
            public string Month { get; set; }
            public double Metric { get; set; }
            public string Team { get; set; }
        }

        private void InitializeBubbleChart()
        {
            // Create a DataTable for bubble chart data
            bubbleData = new DataTable();
            bubbleData.Columns.Add("X", typeof(double));
            bubbleData.Columns.Add("Y", typeof(double));
            bubbleData.Columns.Add("Radius", typeof(double));

            // Add initial rows
            bubbleData.Rows.Add(10d, 20d, 5d);
            bubbleData.Rows.Add(30d, 40d, 8d);
            bubbleData.Rows.Add(50d, 60d, 3d);
            bubbleData.Rows.Add(70d, 80d, 6d);

            // Configure the existing designer-placed control (bitnovaBubbleChart1)
            bitnovaBubbleChart1.DataSource = bubbleData;
            bitnovaBubbleChart1.XMember = "X";
            bitnovaBubbleChart1.YMember = "Y";
            bitnovaBubbleChart1.RadiusMember = "Radius";
            bitnovaBubbleChart1.BackgroundColor = Color.FromArgb(66, 133, 244);
            bitnovaBubbleChart1.HoverBackgroundColor = Color.FromArgb(255, 165, 0); // Orange
            bitnovaBubbleChart1.BorderColor = Color.White;
            bitnovaBubbleChart1.RefreshInterval = 5000;

           

            // Start timer for dynamic updates
            var timer = new Timer { Interval = 5000 };
            timer.Tick += (s, e) =>
            {
                bubbleData.Rows.Add(
                    rnd.NextDouble() * 100,
                    rnd.NextDouble() * 100,
                    2 + rnd.NextDouble() * 6);
                if (bubbleData.Rows.Count > 10) bubbleData.Rows.RemoveAt(0);
                bitnovaBubbleChart1.DataSource = bubbleData;
            };
            timer.Start();
        }


        public class MarketData
        {
            public double Sales { get; set; }
            public double Profit { get; set; }
            public double Volume { get; set; }
        }

    }
}
