﻿namespace BitnovaChartsdemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bitnovaBubbleChart1 = new Bitnova.UI.BitnovaBubbleChart();
            this.bitnovaLineChart1 = new Bitnova.UI.Controls.BitnovaLineChart();
            this.bitnovaPieChart1 = new Bitnova.UI.Controls.BitnovaPieChart();
            this.bitnovaPolarChart1 = new Bitnova.UI.Controls.BitnovaPolarChart();
            this.bitnovaRadarChart1 = new Bitnova.UI.Controls.BitnovaRadarChart();
            this.bitnovaDoughnutChart1 = new Bitnova.UI.Controls.BitnovaDoughnutChart();
            this.bitnovaAreaChart1 = new Bitnova.UI.Controls.BitnovaAreaChart();
            this.bitnovaBarChart1 = new Bitnova.UI.BitnovaBarChart();
            this.bitnovaShadowPanel1 = new Bitnova.UI.BitnovaShadowPanel();
            this.bitnovaLabel1 = new Bitnova.UI.BitnovaLabel();
            this.bitnovaShadowPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bitnovaBubbleChart1
            // 
            this.bitnovaBubbleChart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.bitnovaBubbleChart1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(133)))), ((int)(((byte)(244)))));
            this.bitnovaBubbleChart1.BorderColor = System.Drawing.Color.Black;
            this.bitnovaBubbleChart1.BorderWidth = 1;
            this.bitnovaBubbleChart1.DataSource = null;
            this.bitnovaBubbleChart1.ForeColor = System.Drawing.Color.White;
            this.bitnovaBubbleChart1.GridLineCount = 5;
            this.bitnovaBubbleChart1.HoverBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(133)))), ((int)(((byte)(244)))));
            this.bitnovaBubbleChart1.HoverBorderWidth = 2;
            this.bitnovaBubbleChart1.HoverRadiusIncrease = 2;
            this.bitnovaBubbleChart1.Label = "Bubble Series";
            this.bitnovaBubbleChart1.Location = new System.Drawing.Point(1030, 381);
            this.bitnovaBubbleChart1.Name = "bitnovaBubbleChart1";
            this.bitnovaBubbleChart1.Padding = new System.Windows.Forms.Padding(50, 30, 30, 60);
            this.bitnovaBubbleChart1.RadiusMember = null;
            this.bitnovaBubbleChart1.RefreshInterval = 100;
            this.bitnovaBubbleChart1.Size = new System.Drawing.Size(321, 227);
            this.bitnovaBubbleChart1.TabIndex = 8;
            this.bitnovaBubbleChart1.Text = "bitnovaBubbleChart1";
            this.bitnovaBubbleChart1.XAxisLabel = "X";
            this.bitnovaBubbleChart1.XMember = null;
            this.bitnovaBubbleChart1.YAxisLabel = "Y";
            this.bitnovaBubbleChart1.YMember = null;
            // 
            // bitnovaLineChart1
            // 
            this.bitnovaLineChart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.bitnovaLineChart1.DataSource = null;
            this.bitnovaLineChart1.EnableHover = true;
            this.bitnovaLineChart1.Fill = Bitnova.UI.Controls.BitnovaLineChart.FillMode.None;
            this.bitnovaLineChart1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(173)))), ((int)(((byte)(216)))), ((int)(((byte)(230)))));
            this.bitnovaLineChart1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bitnovaLineChart1.ForeColor = System.Drawing.Color.White;
            this.bitnovaLineChart1.InterpolationMode = Bitnova.UI.Controls.BitnovaLineChart.InterpolationModeOption.Linear;
            this.bitnovaLineChart1.IsStepped = false;
            this.bitnovaLineChart1.LabelMember = null;
            this.bitnovaLineChart1.LineTension = 0.4D;
            this.bitnovaLineChart1.Location = new System.Drawing.Point(710, 381);
            this.bitnovaLineChart1.Name = "bitnovaLineChart1";
            this.bitnovaLineChart1.Padding = new System.Windows.Forms.Padding(50, 20, 20, 60);
            this.bitnovaLineChart1.PointBackgroundColor = System.Drawing.Color.Blue;
            this.bitnovaLineChart1.PointBorderColor = System.Drawing.Color.White;
            this.bitnovaLineChart1.PointBorderWidth = 2;
            this.bitnovaLineChart1.PointHoverBackgroundColor = System.Drawing.Color.Red;
            this.bitnovaLineChart1.PointHoverRadius = 6;
            this.bitnovaLineChart1.PointRadius = 4;
            this.bitnovaLineChart1.SeriesMember = null;
            this.bitnovaLineChart1.ShowLines = true;
            this.bitnovaLineChart1.ShowPoints = true;
            this.bitnovaLineChart1.Size = new System.Drawing.Size(313, 227);
            this.bitnovaLineChart1.TabIndex = 7;
            this.bitnovaLineChart1.Text = "bitnovaLineChart1";
            this.bitnovaLineChart1.ValueMember = null;
            // 
            // bitnovaPieChart1
            // 
            this.bitnovaPieChart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.bitnovaPieChart1.BackgroundColors = ((System.Collections.Generic.List<System.Drawing.Color>)(resources.GetObject("bitnovaPieChart1.BackgroundColors")));
            this.bitnovaPieChart1.BorderColor = System.Drawing.Color.White;
            this.bitnovaPieChart1.BorderWidth = 1F;
            this.bitnovaPieChart1.ChartBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.bitnovaPieChart1.DataSource = null;
            this.bitnovaPieChart1.EnableAnimation = true;
            this.bitnovaPieChart1.EnableHover = true;
            this.bitnovaPieChart1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bitnovaPieChart1.ForeColor = System.Drawing.Color.White;
            this.bitnovaPieChart1.HoverBackgroundColor = System.Drawing.Color.Yellow;
            this.bitnovaPieChart1.HoverBorderColor = System.Drawing.Color.White;
            this.bitnovaPieChart1.HoverBorderWidth = 2F;
            this.bitnovaPieChart1.LabelMember = null;
            this.bitnovaPieChart1.Location = new System.Drawing.Point(388, 381);
            this.bitnovaPieChart1.Name = "bitnovaPieChart1";
            this.bitnovaPieChart1.Padding = new System.Windows.Forms.Padding(20);
            this.bitnovaPieChart1.Size = new System.Drawing.Size(315, 227);
            this.bitnovaPieChart1.TabIndex = 6;
            this.bitnovaPieChart1.Text = "bitnovaPieChart1";
            this.bitnovaPieChart1.ValueMember = null;
            // 
            // bitnovaPolarChart1
            // 
            this.bitnovaPolarChart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.bitnovaPolarChart1.DataSource = null;
            this.bitnovaPolarChart1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bitnovaPolarChart1.ForeColor = System.Drawing.Color.White;
            this.bitnovaPolarChart1.LabelMember = null;
            this.bitnovaPolarChart1.Labels = ((System.Collections.Generic.List<string>)(resources.GetObject("bitnovaPolarChart1.Labels")));
            this.bitnovaPolarChart1.Location = new System.Drawing.Point(36, 381);
            this.bitnovaPolarChart1.Name = "bitnovaPolarChart1";
            this.bitnovaPolarChart1.Padding = new System.Windows.Forms.Padding(40);
            this.bitnovaPolarChart1.RefreshInterval = 2000;
            this.bitnovaPolarChart1.SeriesColors = ((System.Collections.Generic.List<System.Drawing.Color>)(resources.GetObject("bitnovaPolarChart1.SeriesColors")));
            this.bitnovaPolarChart1.ShowLegend = true;
            this.bitnovaPolarChart1.Size = new System.Drawing.Size(335, 227);
            this.bitnovaPolarChart1.TabIndex = 5;
            this.bitnovaPolarChart1.Text = "bitnovaPolarChart1";
            this.bitnovaPolarChart1.ValueMember = null;
            this.bitnovaPolarChart1.Values = ((System.Collections.Generic.List<double>)(resources.GetObject("bitnovaPolarChart1.Values")));
            // 
            // bitnovaRadarChart1
            // 
            this.bitnovaRadarChart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.bitnovaRadarChart1.BorderColor = System.Drawing.Color.Blue;
            this.bitnovaRadarChart1.BorderWidth = 2;
            this.bitnovaRadarChart1.DataSource = null;
            this.bitnovaRadarChart1.Fill = false;
            this.bitnovaRadarChart1.ForeColor = System.Drawing.Color.White;
            this.bitnovaRadarChart1.GridLineCount = 5;
            this.bitnovaRadarChart1.LabelMember = null;
            this.bitnovaRadarChart1.Labels = ((System.Collections.Generic.List<string>)(resources.GetObject("bitnovaRadarChart1.Labels")));
            this.bitnovaRadarChart1.Location = new System.Drawing.Point(1029, 114);
            this.bitnovaRadarChart1.Name = "bitnovaRadarChart1";
            this.bitnovaRadarChart1.Padding = new System.Windows.Forms.Padding(50);
            this.bitnovaRadarChart1.PointBorderColor = System.Drawing.Color.Black;
            this.bitnovaRadarChart1.PointBorderWidth = 1;
            this.bitnovaRadarChart1.PointColor = System.Drawing.Color.White;
            this.bitnovaRadarChart1.PointHoverColor = System.Drawing.Color.Orange;
            this.bitnovaRadarChart1.PointHoverRadius = 7;
            this.bitnovaRadarChart1.PointRadius = 5;
            this.bitnovaRadarChart1.PointRotation = 0;
            this.bitnovaRadarChart1.RefreshInterval = 0;
            this.bitnovaRadarChart1.ScaleMax = 100;
            this.bitnovaRadarChart1.SeriesMember = null;
            this.bitnovaRadarChart1.ShowLegend = true;
            this.bitnovaRadarChart1.Size = new System.Drawing.Size(322, 213);
            this.bitnovaRadarChart1.TabIndex = 4;
            this.bitnovaRadarChart1.Text = "bitnovaRadarChart1";
            this.bitnovaRadarChart1.Title = "Radar Chart";
            this.bitnovaRadarChart1.ValueMember = null;
            // 
            // bitnovaDoughnutChart1
            // 
            this.bitnovaDoughnutChart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.bitnovaDoughnutChart1.BackgroundColors = ((System.Collections.Generic.List<System.Drawing.Color>)(resources.GetObject("bitnovaDoughnutChart1.BackgroundColors")));
            this.bitnovaDoughnutChart1.BorderColor = System.Drawing.Color.White;
            this.bitnovaDoughnutChart1.BorderWidth = 1F;
            this.bitnovaDoughnutChart1.ChartBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.bitnovaDoughnutChart1.DataSource = null;
            this.bitnovaDoughnutChart1.EnableAnimations = true;
            this.bitnovaDoughnutChart1.EnableHover = true;
            this.bitnovaDoughnutChart1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bitnovaDoughnutChart1.ForeColor = System.Drawing.Color.White;
            this.bitnovaDoughnutChart1.HoverBackgroundColor = System.Drawing.Color.Yellow;
            this.bitnovaDoughnutChart1.HoverBorderColor = System.Drawing.Color.White;
            this.bitnovaDoughnutChart1.HoverBorderWidth = 2F;
            this.bitnovaDoughnutChart1.InnerRadiusPadding = 8;
            this.bitnovaDoughnutChart1.LabelMember = null;
            this.bitnovaDoughnutChart1.LegendSpacing = 12;
            this.bitnovaDoughnutChart1.Location = new System.Drawing.Point(709, 114);
            this.bitnovaDoughnutChart1.Name = "bitnovaDoughnutChart1";
            this.bitnovaDoughnutChart1.Padding = new System.Windows.Forms.Padding(20);
            this.bitnovaDoughnutChart1.RefreshInterval = 2000;
            this.bitnovaDoughnutChart1.SeriesMember = null;
            this.bitnovaDoughnutChart1.ShowLegend = true;
            this.bitnovaDoughnutChart1.Size = new System.Drawing.Size(314, 214);
            this.bitnovaDoughnutChart1.TabIndex = 3;
            this.bitnovaDoughnutChart1.Text = "bitnovaDoughnutChart1";
            this.bitnovaDoughnutChart1.ValueMember = null;
            // 
            // bitnovaAreaChart1
            // 
            this.bitnovaAreaChart1.AnimationSpeed = 20;
            this.bitnovaAreaChart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.bitnovaAreaChart1.ChartBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.bitnovaAreaChart1.DataSource = null;
            this.bitnovaAreaChart1.EnableAnimation = true;
            this.bitnovaAreaChart1.EnableHover = true;
            this.bitnovaAreaChart1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(100)))), ((int)(((byte)(149)))), ((int)(((byte)(237)))));
            this.bitnovaAreaChart1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bitnovaAreaChart1.ForeColor = System.Drawing.Color.White;
            this.bitnovaAreaChart1.HoverPointColor = System.Drawing.Color.Yellow;
            this.bitnovaAreaChart1.LabelMember = null;
            this.bitnovaAreaChart1.LineColor = System.Drawing.Color.CornflowerBlue;
            this.bitnovaAreaChart1.LineWidth = 2F;
            this.bitnovaAreaChart1.Location = new System.Drawing.Point(388, 114);
            this.bitnovaAreaChart1.Name = "bitnovaAreaChart1";
            this.bitnovaAreaChart1.Size = new System.Drawing.Size(315, 214);
            this.bitnovaAreaChart1.TabIndex = 2;
            this.bitnovaAreaChart1.Text = "bitnovaAreaChart1";
            this.bitnovaAreaChart1.ValueMember = null;
            // 
            // bitnovaBarChart1
            // 
            this.bitnovaBarChart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.bitnovaBarChart1.ChartBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.bitnovaBarChart1.DataSource = null;
            this.bitnovaBarChart1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bitnovaBarChart1.ForeColor = System.Drawing.Color.White;
            this.bitnovaBarChart1.GridLineCount = 5;
            this.bitnovaBarChart1.LabelMember = null;
            this.bitnovaBarChart1.Location = new System.Drawing.Point(36, 114);
            this.bitnovaBarChart1.Name = "bitnovaBarChart1";
            this.bitnovaBarChart1.Padding = new System.Windows.Forms.Padding(60, 20, 20, 60);
            this.bitnovaBarChart1.RealTime = true;
            this.bitnovaBarChart1.RefreshInterval = 2000;
            this.bitnovaBarChart1.SeriesMember = null;
            this.bitnovaBarChart1.ShowLegend = true;
            this.bitnovaBarChart1.Size = new System.Drawing.Size(335, 214);
            this.bitnovaBarChart1.TabIndex = 1;
            this.bitnovaBarChart1.Text = "bitnovaBarChart1";
            this.bitnovaBarChart1.ValueMember = null;
            this.bitnovaBarChart1.YAxisLabel = "Values";
            // 
            // bitnovaShadowPanel1
            // 
            this.bitnovaShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bitnovaShadowPanel1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.bitnovaShadowPanel1.BorderThickness = 1;
            this.bitnovaShadowPanel1.Controls.Add(this.bitnovaLabel1);
            this.bitnovaShadowPanel1.CornerRadius = 10;
            this.bitnovaShadowPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.bitnovaShadowPanel1.Location = new System.Drawing.Point(0, 0);
            this.bitnovaShadowPanel1.Name = "bitnovaShadowPanel1";
            this.bitnovaShadowPanel1.PanelBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(23)))), ((int)(((byte)(168)))));
            this.bitnovaShadowPanel1.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bitnovaShadowPanel1.ShadowDepth = 5;
            this.bitnovaShadowPanel1.Size = new System.Drawing.Size(1363, 56);
            this.bitnovaShadowPanel1.TabIndex = 0;
            // 
            // bitnovaLabel1
            // 
            this.bitnovaLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bitnovaLabel1.AutoEllipsis = false;
            this.bitnovaLabel1.AutoSizeToFit = false;
            this.bitnovaLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bitnovaLabel1.Font = new System.Drawing.Font("Segoe UI Semibold", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bitnovaLabel1.ForeColor = System.Drawing.Color.White;
            this.bitnovaLabel1.GlowColor = System.Drawing.Color.White;
            this.bitnovaLabel1.GlowStrength = 5;
            this.bitnovaLabel1.GradientColor1 = System.Drawing.Color.DeepSkyBlue;
            this.bitnovaLabel1.GradientColor2 = System.Drawing.Color.MediumVioletRed;
            this.bitnovaLabel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.bitnovaLabel1.Location = new System.Drawing.Point(585, 12);
            this.bitnovaLabel1.Name = "bitnovaLabel1";
            this.bitnovaLabel1.ShadowColor = System.Drawing.Color.Gray;
            this.bitnovaLabel1.ShadowDepth = 2;
            this.bitnovaLabel1.Size = new System.Drawing.Size(199, 23);
            this.bitnovaLabel1.TabIndex = 0;
            this.bitnovaLabel1.Text = "Bitnova Charts";
            this.bitnovaLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bitnovaLabel1.UseGlow = false;
            this.bitnovaLabel1.UseGradient = false;
            this.bitnovaLabel1.UseShadow = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(1363, 691);
            this.Controls.Add(this.bitnovaBubbleChart1);
            this.Controls.Add(this.bitnovaLineChart1);
            this.Controls.Add(this.bitnovaPieChart1);
            this.Controls.Add(this.bitnovaPolarChart1);
            this.Controls.Add(this.bitnovaRadarChart1);
            this.Controls.Add(this.bitnovaDoughnutChart1);
            this.Controls.Add(this.bitnovaAreaChart1);
            this.Controls.Add(this.bitnovaBarChart1);
            this.Controls.Add(this.bitnovaShadowPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.bitnovaShadowPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Bitnova.UI.BitnovaShadowPanel bitnovaShadowPanel1;
        private Bitnova.UI.BitnovaLabel bitnovaLabel1;
        private Bitnova.UI.BitnovaBarChart bitnovaBarChart1;
        private Bitnova.UI.Controls.BitnovaAreaChart bitnovaAreaChart1;
        private Bitnova.UI.Controls.BitnovaDoughnutChart bitnovaDoughnutChart1;
        private Bitnova.UI.Controls.BitnovaRadarChart bitnovaRadarChart1;
        private Bitnova.UI.Controls.BitnovaPolarChart bitnovaPolarChart1;
        private Bitnova.UI.Controls.BitnovaPieChart bitnovaPieChart1;
        private Bitnova.UI.Controls.BitnovaLineChart bitnovaLineChart1;
        private Bitnova.UI.BitnovaBubbleChart bitnovaBubbleChart1;
    }
}

